const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// 飞机参数
const planeWidth = 50;
const planeHeight = 50;
let planeX = canvas.width / 2 - planeWidth / 2;
const planeY = canvas.height - planeHeight - 10;
const planeSpeed = 5;

// 子弹参数
const bulletWidth = 5;
const bulletHeight = 15;
const bulletSpeed = 5;
let bullets = [];

// 敌人参数
const enemyWidth = 30;
const enemyHeight = 30;
let enemies = [];

function drawPlane() {
    ctx.fillStyle = 'blue';
    ctx.fillRect(planeX, planeY, planeWidth, planeHeight);
}

function movePlane(event) {
    if (event.key === 'ArrowLeft' && planeX > 0) {
        planeX -= planeSpeed;
    }
    if (event.key === 'ArrowRight' && planeX < canvas.width - planeWidth) {
        planeX += planeSpeed;
    }
}

function drawBullets() {
    ctx.fillStyle = 'red';
    bullets.forEach((bullet) => {
        ctx.fillRect(bullet.x, bullet.y, bulletWidth, bulletHeight);
        bullet.y -= bulletSpeed;
        // 移除飞出画面的子弹
        if (bullet.y < 0) {
            bullets.shift();
        }
    });
}

function createBullet() {
    bullets.push({
        x: planeX + planeWidth / 2 - bulletWidth / 2,
        y: planeY,
    });
}

function drawEnemies() {
    ctx.fillStyle = 'green';
    enemies.forEach((enemy) => {
        ctx.fillRect(enemy.x, enemy.y, enemyWidth, enemyHeight);
        enemy.y += 1;
        // 检查子弹是否击中敌人
        bullets.forEach((bullet, bulletIndex) => {
            if (
                bullet.x < enemy.x + enemyWidth &&
                bullet.x + bulletWidth > enemy.x &&
                bullet.y < enemy.y + enemyHeight &&
                bullet.y + bulletHeight > enemy.y
            ) {
                // 击中则移除该子弹和敌人
                bullets.splice(bulletIndex, 1);
                enemies.splice(enemies.indexOf(enemy), 1);
            }
        });
    });
}

function createEnemy() {
    const x = Math.random() * (canvas.width - enemyWidth);
    enemies.push({ x: x, y: 0 });
}

function gameLoop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawPlane();
    drawBullets();
    drawEnemies();
    createEnemy();
    requestAnimationFrame(gameLoop);
}

// 监听键盘事件
document.addEventListener('keydown', movePlane);
document.addEventListener('keydown', (event) => {
    if (event.key === ' ') {
        createBullet();
    }
});

// 启动游戏循环
gameLoop();